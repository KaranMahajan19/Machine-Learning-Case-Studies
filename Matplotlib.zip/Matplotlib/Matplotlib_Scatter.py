import matplotlib.pyplot as plt
import numpy as np

def main():

	print("Demonstration on Maptlotlib")

	X_Points = np.array([5,7,8,7,2,17,2,9,4,11,12,9,6])

	Y_Points = np.array([99,86,87,88,111,86,103,87,94,78,77,85,86])

	plt.plot(X_Points,Y_Points)

	plt.scatter(X_Points,Y_Points, color='#ef5423')
	
	for i,j in zip(X_Points,Y_Points):
		plt.text(i,j+0.2, '({},{})'.format(i,j))

	plt.show()

if __name__=="__main__":

	main()