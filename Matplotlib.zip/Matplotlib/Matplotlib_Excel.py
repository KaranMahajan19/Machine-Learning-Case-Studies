
import pandas as pd
import matplotlib.pyplot as plt

def MatplotLib(Data):

	Sorted_Data = Data.sort_values(['Age'], ascending=True)
	print("Sorted data")
	print(Sorted_Data)

	Data['Age'].plot(kind="hist")
	plt.show()

	Data['Age'].plot(kind="barh")
	plt.show()

def main():

	excel_file = 'Data.xlsx'
	data = pd.read_excel(excel_file)

	print("All data from excel file")
	print(data)
	print()
	print("First 5 rows from file")
	print(data.head())
	print()
	print("First 4 rows from")
	print(data.head(4))
	print()
	print("Last 3 rows from file")
	print(data.tail(3))
	print()
	print("Last 4 rows from file")
	print(data.tail(4))
	print()
	print(data.shape)

	MatplotLib(data)

if __name__=="__main__":
	main()