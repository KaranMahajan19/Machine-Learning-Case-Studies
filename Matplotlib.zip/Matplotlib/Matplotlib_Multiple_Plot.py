import matplotlib.pyplot as plt
import numpy as np

def main():

	print("Demonstration on Maptlotlib")

	X_Points = np.array([1,1,4,7,7])

	Y_Points = np.array([0,7,4,7,0])

	plt.plot(X_Points,Y_Points)

	plt.scatter(X_Points,Y_Points, color='#ef5423')

	for i,j in zip(X_Points,Y_Points):
		plt.text(i,j+0.2, '({},{})'.format(i,j))

	plt.show()

if __name__=="__main__":

	main()