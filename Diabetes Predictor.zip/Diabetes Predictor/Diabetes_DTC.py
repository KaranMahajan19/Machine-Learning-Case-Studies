
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from matplotlib import pyplot as plt
import numpy as np

print("-----Diabetes Predictor using Logistic Regerssion-----")


diabetes = pd.read_csv('diabetes.csv')

print("Columns of Dataset")
print(diabetes.columns)

print("First 5 records of Dataset")
print(diabetes.head())

print("Dimension of diabetes data : {}".format(diabetes.shape))

X_Train,X_Test,Y_Train,Y_Test = train_test_split(diabetes.loc[:,diabetes.columns != 'Outcome'], diabetes['Outcome'], stratify = diabetes['Outcome'],random_state = 66)

DTC = DecisionTreeClassifier(random_state = 0)
DTC.fit(X_Train, Y_Train)
print("Training set accuracy : {:.3f}".format(DTC.score(X_Train,Y_Train)))
print("Test set accuracy : {:.3f}".format(DTC.score(X_Test, Y_Test)))

DTC = DecisionTreeClassifier(max_depth = 3, random_state=0)
DTC.fit(X_Train, Y_Train)
print("Training set accuracy : {:.3f}".format(DTC.score(X_Train,Y_Train)))
print("Test set accuracy : {:.3f}".format(DTC.score(X_Test,Y_Test)))

print("Feature importances_diabetes : \n {}".format(DTC.feature_importances_))

def plot_feature_importances_diabetes(model):
	plt.figure(figsize = (8,6))
	n_features = 8
	plt.barh(range(n_features),model.feature_importances_,align = 'center')
	diabetes_features = [x for i, x in enumerate(diabetes.columns) if i != 8]
	plt.yticks(np.arange(n_features),diabetes_features)
	plt.xlabel("Feature Importance")
	plt.ylabel("Features")
	plt.ylim(-1,n_features)
	plt.show()



plot_feature_importances_diabetes(DTC)