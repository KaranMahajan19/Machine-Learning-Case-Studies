
from warnings import simplefilter
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression

simplefilter(action='ignore', category=FutureWarning)

print("-----Diabetes Predictor using Logistic Regerssion-----")


diabetes = pd.read_csv('diabetes.csv')

print("Columns of Dataset")
print(diabetes.columns)

print("First 5 records of Dataset")
print(diabetes.head())

print("Dimension of diabetes data : {}".format(diabetes.shape))

X_Train,X_Test,Y_Train,Y_Test = train_test_split(diabetes.loc[:,diabetes.columns != 'Outcome'], diabetes['Outcome'], stratify = diabetes['Outcome'],random_state = 66)

Log_Regression = LogisticRegression().fit(X_Train, Y_Train)

print("Training set accuracy : {:.3f}".format(Log_Regression.score(X_Train,Y_Train)))

print("Test set accuracy : {:.3f}".format(Log_Regression.score(X_Test, Y_Test)))

Log_Regression_001 = LogisticRegression(C = 0.01).fit(X_Train, Y_Train)

print("Training set accuracy : {:.3f}".format(Log_Regression_001.score(X_Train,Y_Train)))

print("Test set accuracy : {:.3f}".format(Log_Regression_001.score(X_Test,Y_Test)))
