import numpy as nu
import pandas as pd
from sklearn import preprocessing
from sklearn.neighbors import KNeighborsClassifier

def Play_Predictor(Data_Path):

	# Step 1 : Load the data
	data = pd.read_csv(Data_Path,index_col=0)

	print("Size of Actual dataset : ",len(data))

	# Step 2 : Clean, Prepare & manipulate data
	Feature_Names = ['Whether','Temperature']

	print("Names of features : ",Feature_Names)

	whether = data.Whether
	Temperature = data.Temperature
	play = data.Play

	# Creating label Encoder
	le = preprocessing.LabelEncoder()

	# Converting string labels into numbers.
	whether_encoded = le.fit_transform(whether)
	print("Whether : ")
	print(whether_encoded)

	# Converting string labels into numbers
	temp_encoded = le.fit_transform(Temperature)
	label = le.fit_transform(play)
	print("Temperature")
	print(temp_encoded)

	# Combining weather and temp into single list of tuples
	features = list(zip(whether_encoded,temp_encoded))

	# Step 3 : Train the data
	model = KNeighborsClassifier(n_neighbors = 3)

	# Train the model using the training sets
	model.fit(features,label)

	# Step 4 : Test the data
	predicted = model.predict([[0,2]])	# 0 : Overcast, 2 : Mild
	print(predicted)

def main():
	print("-----Play PRedictor using K Nearest Neighbor  alogrithm")

	Play_Predictor("PlayPredictor.csv")

if __name__=="__main__":
	main()