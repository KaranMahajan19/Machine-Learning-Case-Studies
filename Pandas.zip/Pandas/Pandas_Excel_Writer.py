import pandas as pd

def main():
	
	print("Demonstration on Excel")	

	Data_Frame = pd.DataFrame({'Data' : [11,21,51,101,111,121],
								'Float':[1.1,2.1,5.1,10.1,11.1,12.1]})

	writer = pd.ExcelWriter('ExcelWriter.xlsx',engine='xlsxwriter')

	Data_Frame.to_excel(writer, sheet_name='Sheet 1')

	writer.save()

if __name__=="__main__":
	main()