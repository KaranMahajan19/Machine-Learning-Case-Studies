
import pandas as pd
import numpy as np

def main():

	print("Pandas Series Demonstration")

	data = np.array(['a','b','c','d','e'])

	print("Data : ",data)

	S = pd.Series(data)

	print("Data of S[0] : ",S[0])

	data = np.array(['a','b','c','d','e'])

	# Customised index
	S = pd.Series(data,index=[101,201,301,401,501])

	print("Data of S[101] : ",S[101])

	data = {'a' : 0.1,'b' : 0.2,'c': 0.3,'d' : 0.4,'e' : 0.5}

	S = pd.Series(data)
	print(S)

	S = pd.Series([1,2,3,4,5], index = ['a','b','c','d','e'])
	
	print(S['a'])


if __name__=="__main__":
	main()