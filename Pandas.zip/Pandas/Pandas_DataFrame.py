
import pandas as pd

def main():

	print("Pandas Data_Frame Demonstration")

	print("Dataframe with list")
	data = [1,2,3,4,5]

	Data_Frame = pd.DataFrame(data)

	print(Data_Frame)

	data = [['Samsung',10000],['Redmi',20000],['OnePlus',30000],['Asus',40000],['Apple',50000]]

	Data_Frame = pd.DataFrame(data,columns=['Mo.Names','Price'])

	print(Data_Frame)

	print()
	
	print("--New Dataframe--")
	
	data = {'Names':['Samsung','Redmi','OnePlus','Asus','Apple'],'Price':[10000,20000,30000,40000,50000]}	

	Data_Frame = pd.DataFrame(data)

	print(Data_Frame)

	print()

	print("--New Dataframe--")
	data = [{'Name':'Samsung','Price':10000},
			{'Name':'Redmi','Price':20000},
			{'Name':'OnePlus','Price':30000},
			{'Name':'Asus','Price':40000},
			{'Name':'Apple','Price':50000}]

	Data_Frame = pd.DataFrame(data)

	print(Data_Frame)

if __name__=="__main__":
	main()