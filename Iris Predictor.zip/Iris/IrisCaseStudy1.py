
from sklearn.datasets import load_iris
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split

def K_Neighbors_Classifier():
	
	# Step 1: Load the data
	Dataset = load_iris()			

	Data = Dataset.data
	Target = Dataset.target

	# Step 2 : Manipulate the data
	# Reffer Diagram (Telegram/python/IrisCaseStudy1.py)								# keyword arg
	Data_Train, Data_Test, Target_Train, Target_Test = train_test_split(Data, Target, test_size = 0.5)

	Classifier = KNeighborsClassifier()

	# Step 3 : Build the model
	Classifier.fit(Data_Train, Target_Train)	# Train the data

	# Step 4 : Test the model
	Predictions = Classifier.predict(Data_Test)	# Test the data

	Accuracy = accuracy_score(Target_Test, Predictions)

	# Step 5 : Improve --Missing

	return Accuracy

def main():
	Ret = K_Neighbors_Classifier()

	print("Accuracy of Iris Dataset with KNN is : ",Ret)

	print("Accuracy of Iris Dataset with KNN is : ",Ret*100)


if __name__=="__main__":
	main()