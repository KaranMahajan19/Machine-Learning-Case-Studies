
from sklearn.tree import DecisionTreeClassifier
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

def Decision_Tree_Classifier():
	Dataset = load_iris()			# Step 1: Load the data

	Data = Dataset.data
	Target = Dataset.target

	# step 2: Manipulate the data
	# Reffer Diagram (Telegram/python/IrisCaseStudy1.py)								# keyword arg
	Data_Train, Data_Test, Target_Train, Target_Test = train_test_split(Data, Target, test_size = 0.5)

	Classifier = DecisionTreeClassifier()
	
	# step 3: Train the data
	Classifier.fit(Data_Train, Target_Train)	

	# step 4: Test the data
	Predictions = Classifier.predict(Data_Test)	

	Accuracy = accuracy_score(Target_Test, Predictions)

	return Accuracy

def main():
	Ret = Decision_Tree_Classifier()

	print("Accuracy of Iris Dataset with DTC is : ",Ret*100)

if __name__=="__main__":
	main()