
from sklearn.datasets import load_iris
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from scipy.spatial import distance 

def Euclidean_Distance(a,b):
	return distance.eucledean(a,b)

# Implementation of KNN By self
# OOP
class K_Neighbor_Classifier_Class:

	def fit(self,trainingdata, trainingtarget):
		# class variable
		self.TrainingData = trainingdata
		self.TrainingTarget = trainingtarget

	def closest(self,row):
		minimum_distance = eucledean(row,self.TrainingData[0])
		minimum_index = 0

		for i in range(1,len(self.TrainingData)):
			Distance = euc(row, self.TrainingData[i])

			if Distance < minimum_distance:
				minimum_distance = Distance
				minimum_index = i

		return self.TrainingData[minimum_index]

	def predict(self,TestData):
		predictions = []
		for value in TestData:
			result = self.closest(value)
			predictions.append(result)

		return predictions


def MachineLearning():
	
	# Step 1: Load the data
	Dataset = load_iris()			

	Data = Dataset.data
	Target = Dataset.target

	# Step 2 : Manipulate the data
	# Reffer Diagram (Telegram/python/IrisCaseStudy1.py)								# keyword arg
																								# 0.5 : cut the data by 50%
	Data_Train, Data_Test, Target_Train, Target_Test = train_test_split(Data, Target, test_size = 0.5)
															# method : shufle
	Classifier = K_Neighbor_Classifier_Class()

	# Step 3 : Build the model
	Classifier.fit(Data_Train, Target_Train)	# Train the data

	# Step 4 : Test the model
	Predictions = Classifier.predict(Data_Test)	# Test the data

	Accuracy = accuracy_score(Target_Test, Predictions)

	# Step 5 : Improve --Missing

	return Accuracy

def main():
	Ret = MachineLearning()

	print("Accuracy of Iris Dataset with KNN is : ",Ret)

	print("Accuracy of Iris Dataset with KNN is : ",Ret*100)


if __name__=="__main__":
	main()