import numpy as np
from sklearn.datasets import load_iris
from sklearn import tree

iris = load_iris()

print("Features name of iris data set.")
print(iris.feature_names)

print("Targt names of iris data set.")
print(iris.target_names)

# Indices of removed elements
test_index = [1,51,101]

# Training data with removed elements
train_target = np.delete(iris.target,test_index)
train_data = np.delete(iris.data,test_index,axis = 0)

# Testing data for testing on training data
test_target = iris.target[test_index]
test_data = iris.data[test_index]

# from decision tree classifier
classifier = tree.DecisionTreeClassifier()

# Apply training data to from tree
classifier.fit(train_data,train_target)

print("Values that we removed for testing")
print(test_target)

print("Result of testing")
print(classifier.predict(test_data))

for i in range(len(iris.target)):
	print("ID : %d, Lable : %s, Features : %s"%(i,iris.data[i],iris.target[i]))