
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def Linear_Regression_Predictor():

	# Load the data
	X = [1,2,3,4,5]
	Y = [3,4,2,4,5]

	# Least Square method
	# X_Bar
	# Y_Bar
	mean_X = np.mean(X)
	mean_Y = np.mean(Y)

	print("Mean of Independent variable X : ",mean_X)
	print("Mean of Dependent variable Y : ",mean_Y)

	n = len(X)

	numerator = 0
	denomenator = 0

	# Equation of line is : Y = mX + C

	for i in range(n):
		numerator += (X[i] - mean_X) * (Y[i] - mean_Y)
		denomenator += (X[i] - mean_X)**2

	# m = Sum(X - X_Bar)
	m = numerator / denomenator

	# c = y' - mx'

	c = mean_Y - (m * mean_X)

	print("Slope of Regression line is : ",m)
	print("Y intercept of Regression line is : ",c)

	# Display plotting of above points

	x = np.linspace(1,6,n)

	y = c + m * x

	plt.scatter(X,Y, color='#ef5423', label='scatter plot')

	plt.xlabel('X - Independent Variable')
	plt.ylabel('Y - Dependent Variable')

	plt.legend()
	plt.show()

	# Findout goodness of fit i.e, R Square
	ss_t = 0
	ss_r = 0

	for i in range(n):
		Y_Prediction = c + m * X[i]
		ss_t += (Y[i] - mean_Y)**2
		ss_r += (Y[i] - Y_Prediction)**2

	r2 = 1 - (ss_r/ss_t)

	print("Goodness of fit using R Square method is : ",r2)



def main():

	print("Linear Regression")

	Linear_Regression_Predictor()

if __name__=="__main__":
	main()