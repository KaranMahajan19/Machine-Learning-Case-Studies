# import required library
from sklearn import tree		#import sklearn

# Load the dataset    
         
# Dont allow string             #list of list	
Features = [[35,"Rough"],[47,"Rough"],[90,"Smooth"],[48,"Rough"],[90,"Smooth"],[35,"Rough"],[92,"Smooth"],[35,"Rough"],[35,"Rough"],[35,"Rough"],[96,"Smooth"],[43,"Rough"],[110,"Smooth"],[35,"Rough"],[95,"Smooth"]]
Labels = ["Tennis","Tennis","Cricket","Tennis","Cricket","Tennis","Cricket","Tennis","Tennis","Tennis","Cricket","Tennis","Cricket","Tennis","Cricket"]

# Decide the machine learning algorithm
obj = tree.DecisionTreeClassifier()		# Classification

# Perform the triaing of model
obj = obj.fit(Features, Labels)			# Training (fit)

# Perform the testing
print(obj.predict([[97,"Smooth"]]))

# Error Occured